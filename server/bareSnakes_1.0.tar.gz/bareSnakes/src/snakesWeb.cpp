#include <Rcpp.h>
#include <sstream>
#include <string>
using namespace Rcpp;
//This funciton is used by the game to see if the 
//snake hit its body. 

// [[Rcpp::export]]
bool gameOver(List x) {
  IntegerVector head = x[0];
  int len = x.size();
  for(int i=1;i<len;i++)
  {
    IntegerVector y = x[i];
    if(y[0] == head[0] && y[1] == head[1])
      return true;
  }
  return false;
}

// [[Rcpp::export]]
void moveSnakeC(int arenaSize) {
  
  Environment env;
  
  Environment x = env["snakes"];
  CharacterVector snakeId = x.ls("all");

  Environment prevD = env["prevkey"];
  
  int num = snakeId.length();
  
  int prevDir = 0,dir;
  for(int j = 0; j<num; j++)
  {
    std::string v_id = std::string(snakeId[j]);
      
    prevDir = as<int>(prevD[v_id]);
    
    List e = as<List>(x[v_id]);
    int len = e.size();

    List out(len);
    
    for(int i = 0;i<len;i++)
    {
      IntegerVector y = e[i];
      dir = y[2];
      y[2] = prevDir;
      prevDir = dir;
      
      if(y[2]==1) y[0] = y[0]-1;
      else if(y[2]==2) y[0] = y[0]+1;
      else if(y[2]==3) y[1] = y[1]+1;
      else if(y[2]==4) y[1] = y[1]-1;
      
      if(y[0] > arenaSize) y[0] = 0; 
      if(y[1] > arenaSize) y[1] = 0;
      if(y[0] < 0) y[0] = arenaSize;
      if(y[1] < 0) y[1] = arenaSize;
      
      out[i] = y;
    }
    x[v_id] = out;
  }
}

// [[Rcpp::export]]
CharacterVector snakeData(bool notAll)
{
  List x = as<List>(Environment::global_env()["snakes"]);
  int len = x.size();
  CharacterVector out(1);
  
  std::stringstream ss;
  ss << "[";
  char comma = ',';
  for(int j = 0;j<len;j++)
  {
    ss << "[";
    
    List e = as<List>(x[j]);
    int ilen = e.size();
    
    bool yCh = (as<IntegerVector>(e[0])[1] == as<IntegerVector>(e[1])[1]);
    
    for(int i=0;i<ilen-1;i++)
    {
      IntegerVector y = e[i];
      
      if(notAll)
      {
        IntegerVector z = e[i+1];
        if(yCh){
          if(y[0]==z[0]) continue;
        }
        else
        {
          if(y[1]==z[1]) continue;
        }
        yCh = !yCh;
      }
      ss << "[" << y[0] << "," << y[1] << "],";
    }
    if(j==len-1) comma = ']';
    ss << "[" << as<IntegerVector>(e[ilen-1])[0] <<"," << as<IntegerVector>(e[ilen-1])[1] << "]]"<<comma;
  }
  
  out = ss.str();
  return out;
}

// [[Rcpp::export]]
bool captor(NumericVector food)
{
  Environment env;
  
  Environment x = env["snakes"];
  Environment cF = env["capturedFood"];
  CharacterVector snakeId = x.ls("all");

  int len = snakeId.size();
  for(int i=0;i<len;i++)
  {
    std::string v_id = std::string(snakeId[i]);
    
    List e = as<List>(x[v_id]);
    List ce = as<List>(cF[v_id]);
    IntegerVector y = e[0];
    if(y[0] == food[0] && y[1] == food[1])
    {
      ce.push_back(food);
      cF[v_id] = ce;
      return true;
    }
  }
  return false;
}

// [[Rcpp::export]]
List setCrossee(List c)
{
  Environment env;
  
  Environment x = env["snakes"];
  Environment cF = env["capturedFood"];
  CharacterVector snakeId = x.ls("all");
  
  int len = snakeId.size();
  for(int i=0;i<len;i++)
  {
    std::string v_id = std::string(snakeId[i]);
    
    if(as<List>(cF[v_id]).size() == 0) continue;
    
    List e = as<List>(x[v_id]);
    
    IntegerVector y = e[e.size()-1];
    IntegerVector z = as<List>(cF[v_id])[0];
    if(y[0] == z[0] && y[1] == z[1])
    {
      c[v_id] = true;
    }
  }
  return c;
}


  



